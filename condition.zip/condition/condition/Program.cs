﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System;

namespace condition
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your actual age: ");
            int age = Convert.ToInt32(Console.ReadLine());

            if (age > 0)
            {
                if (age < 18)
                {
                    Console.Write("Teenage");
                }
                else if (age >= 18 && age < 60)
                {
                    Console.Write("Adult");
                }
                else
                {
                    Console.Write("Senior Citizen");
                }
            }
            else
            {
                Console.Write("Landing on Earth pending");
            }

            Console.Read();
        }
    }
}
